create function _pg_char_octet_length(typid oid, typmod integer) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function _pg_char_octet_length(oid, integer) owner to bestuser;

